﻿using AutoMapper;
using Test.Data;
using Test.Models;
namespace Test.Services
{
    public class UserService : IUserServices
    {
        private readonly DataContext _context;
        public UserService(DataContext context)
        {
            _context = context;
        }

        public void AddUser(User user)
        {
            var dbUser = _context.Users;
            dbUser.Add(user);
            _context.SaveChanges();
        }

        public List<User> GetUser()
        {
            var dbUser = _context.Users.ToList();
            return dbUser;

        }
       
        public void UpdateUser(User userToUpdate, int id)
        {
            var dbUser = _context.Users;

            foreach(User user in dbUser)
            {
                if(user.UserId == id)
                {

                    user.UserId = userToUpdate.UserId;
                    user.UserName = userToUpdate.UserName;
                    user.UserEmail = userToUpdate.UserEmail;
                    user.UserPhone = userToUpdate.UserPhone;
                    _context.SaveChanges();
                }
            }


        }

        //Delete
        public void DeleteUser(int id)
        {
            var dbUser = _context.Users;
            foreach (User user in dbUser)
            {
                if (user.UserId == id)
                {
                    dbUser.Remove(user);
                    _context.SaveChanges();
                }
            }
            
        }
    }
}




