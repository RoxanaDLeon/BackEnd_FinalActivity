﻿using Microsoft.EntityFrameworkCore;
using Test.Data;
using Test.Models;

namespace Test.Services
{
    public class ItemService : IItemService
    {
        private readonly DataContext _context;
        public ItemService(DataContext context)
        {
            _context = context;
        }


        public void AddItem(Inventory item)
        {
            var dbItem = _context.Items;
            dbItem.Add(item);
            _context.SaveChanges();
        }
        
        public List<Inventory> GetAll()
        {
            var dbItem = _context.Items.ToList();
            return dbItem;
        }

        public List<Inventory> GetByUser(int userId)
        {
            var dbUser = _context.Users.ToList();
            var dbItem = _context.Items.ToList();
            List<Inventory> items = new List<Inventory>();

            foreach (Inventory item in dbItem)
            {
                if(item.userId == userId)
                {
                    items.Add(item);
                }
            }
            return items;
        }

        //Get
        public Inventory GetItem(int id)
        {
            var dbItem = _context.Items.ToList();
            Inventory emptyItem = new Inventory();
            foreach (Inventory item in dbItem)
            {
                if (item.itemId == id)
                {
                    return item;
                }
            }
            return emptyItem;
        }
        //put
        public void UpdateItem(Inventory itemToUpdate, int itemId)
        {
            var dbItem = _context.Items;

            foreach (Inventory item in dbItem)
            {
                if (item.itemId == itemId)
                {

                    item.itemId = itemToUpdate.itemId;
                    item.ItemName = itemToUpdate.ItemName;
                    item.ItemDescription = itemToUpdate.ItemDescription;
                    item.Quantity = itemToUpdate.Quantity;
                    _context.SaveChanges();
                    
                }
            }
        }
        public void TradeItem(int idItem, int userTraded, int userToTrade, int quantityTrade)
        {
            var dbItem = _context.Items;
            foreach (Inventory item in dbItem)
            {
                if(item.itemId == idItem)
                {
                    if(item.userId == userTraded)
                    {
                        if(item.Quantity-quantityTrade > 0)
                        {
                            
                            item.Quantity -= quantityTrade;
                            Inventory item2 = new Inventory();
                            item2.ItemName = item.ItemName;
                            item2.ItemDescription = item.ItemDescription;
                            item2.Quantity = quantityTrade;
                            item2.userId = userToTrade;
                            dbItem.Add(item2);
                            _context.SaveChanges();
                        }
                        else
                        {
                            if(item.Quantity-quantityTrade > 0)
                            {
                                //borrar
                                dbItem.Remove(item);
                                _context.SaveChanges();
                            }
                            
                        }   
                    }
                }
            }
        }


        //delete
        public void DeleteItem(int id)
        {
            var dbItem = _context.Items;
            foreach (Inventory item in dbItem)
            {
                if (item.itemId == id)
                {
                    dbItem.Remove(item);
                    _context.SaveChanges();
                }
            }

        }
    }
}
