﻿namespace Test.Models
{
    public enum UserType
    {
        SuperUser,
        User,
        Client
    }
}
